package fr.utt.lo02.exception;
/**
 * 
 */

/**
 * classe de l'erreur de saisie :generation d une erreur si 'utilisteur tape 
 *n'importe quoi
 * @author NGUYEN-BENDRISS
 * 
 */
public class erreurSaisieException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructeur de cette classe
	 */
	public erreurSaisieException() {
		// TODO Auto-generated constructor stub
		
	}

}
