package fr.utt.lo02.exception;
/**
 * Classe d'erreur :g�n�re une erreur si une des mains dans le jeu est vid�e 
 * @author BENDRISS-NGUYEN
 *
 */
public class mainVideException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
/**
 * constructeur de cette classe
 */
	public mainVideException(){
		super();
		
	}

}
