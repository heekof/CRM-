package fr.utt.lo02.exception;
/**
 * Classe d'erreur :g�n�re une erreur si  le nombre de tours est atteint 
* @author BENDRISS-NGUYEN
 */
public class nbToursException extends Exception{

	

	private static final long serialVersionUID = 1L;
/**
 * Constructeur de cette classe 
 */
	public nbToursException(){
		
	}
	
}
