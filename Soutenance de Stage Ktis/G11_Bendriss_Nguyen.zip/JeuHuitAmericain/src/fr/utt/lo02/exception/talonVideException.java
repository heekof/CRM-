package fr.utt.lo02.exception;
/**
 * Classe d'erreur :g�n�re une erreur si  le talon est vid�
* @author BENDRISS-NGUYEN
 */
public class talonVideException extends Exception {

	
	private static final long serialVersionUID = 1L;
/**
 * constructeur de cette classe
 */
	public talonVideException(){
		super();
	}
	
	
	
	
}
